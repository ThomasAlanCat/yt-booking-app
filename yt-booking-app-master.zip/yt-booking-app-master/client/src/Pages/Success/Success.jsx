const Success = () => {
  return (
    <div>
      <h1 className="heading success center"> Booking Successful</h1>
    </div>
  );
};

export default Success;
