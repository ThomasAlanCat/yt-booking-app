import "./home.styles.scss";
const Home = () => {
  return (
    <div id="home">
      <div className="img-wra">
        <img src="/images/landing-1.jpeg" alt="" />
      </div>
    </div>
  );
};

export default Home;
